import java.util.ArrayList;

/**
 * MailCoach class for Project5
 *
 * @author Siah
 * @version 1.0 11/04/22
 */
public class MailCoach
{
    // instance variables 
    private String destination;
    private double weight;
    private int volume;
    private ArrayList<Shipment> cargo;
    
    // standard constructor
    public MailCoach() {
        this.destination = "";
        this.weight = 0.0;
        this.volume = 0;
        this.cargo = new ArrayList<Shipment>();
    }
    
    // second constructor
    public MailCoach(String destination) {
        this();
        this.destination = destination;
    }
    
    public String getDestination() {
        return this.destination;
    }
    
    public int getVolume() {
        return this.volume;
    }
    
    public double getWeight() {
        return this.weight;
    }
    
    public ArrayList<Shipment> getCargo() {
       return this.cargo; 
    }
    
    public void addShipment(Shipment s) {
        // FIXME: want to add shipment to the cargo object
        if (s.getDestination().equals(this.destination)) {
           this.cargo.add(s);
           this.volume += s.getVolume();
           this.weight += s.getWeight(); 
        }
    }
    
}
