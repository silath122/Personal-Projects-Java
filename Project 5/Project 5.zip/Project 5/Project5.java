import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Project5 {
    //DATE AND TIME YOU FIRST START WORKING ON THIS ASSIGNMENT (date AND time): <--------------------
    //ANSWER: 10/31/22 3:46 PM       <--------------------
    
    //DO NOT ALTER THE MAIN METHOD
    public static void main( String[] args ) {
        //test your entity classes, comment out when you passed all tests
        testShipment();
        testMailCoach();
        
        //readData reads the input file into an array list
        //it fills the array list with Shipment objects
        ArrayList< Shipment > allMail = readData( "week1.txt" );
        
        //sortData goes through the raw data contained in all mail and populates
        //an array list for the destination with MailCoach objects
        ArrayList< MailCoach > stolat = sortData( "Stolat", allMail );
        ArrayList< MailCoach > quirm = sortData( "Quirm", allMail );
        ArrayList< MailCoach > pseudopolis = sortData( "Pseudopolis", allMail );
        ArrayList< MailCoach > borogravia = sortData( "Borogravia", allMail );
        ArrayList< MailCoach > ueberwald = sortData( "Ueberwald", allMail );
        ArrayList< MailCoach > krull = sortData( "Krull", allMail );
        
        //printReport prints the mail coach data dor each destination in turn
        printReport( stolat );
        printReport( quirm );
        printReport( pseudopolis );
        printReport( borogravia );
        printReport( ueberwald );
        printReport( krull );
    }//DO NOT ALTER THE MAIN METHOD
    public static void testShipment() { //DO NOT ALTER THIS METHOD
        Shipment s1 = new Shipment();
        assert s1.getDestination().equals( "" ) && s1.getVolume() == 0 && 
               s1.getId() == 0 && Math.abs( s1.getWeight() - 0 ) < 0.001 : "Shipment standard constructor not working";
        Shipment s2 = new Shipment( 44, "Stolat", 10.5, 13 );
        assert s2.getDestination().equals( "Stolat" ) : "Shipment second costructor destination not set correctly";
        assert s2.getVolume() == 13 : "Shipment second costructor volume not set correctly";
        assert s2.getId() == 44 : "Shipment second costructor id not set correctly";
        assert Math.abs( s2.getWeight() - 10.5 ) < 0.001 : "Shipment second costructor weight not set correctly";
        System.out.println( "Shipment all tests passed" );
    } //DO NOT ALTER THIS METHOD
    public static void testMailCoach() { //DO NOT ALTER THIS METHOD
        MailCoach mc1 = new MailCoach();
        assert mc1.getDestination().equals( "" ) && mc1.getVolume() == 0 && 
               Math.abs( mc1.getWeight() - 0 ) < 0.001 && mc1.getCargo() != null : "MailCoach standard constructor not working";
        MailCoach mc2 = new MailCoach( "Stolat" );  
        assert mc2.getDestination().equals( "Stolat" ) && mc2.getVolume() == 0 && 
               Math.abs( mc2.getWeight() - 0 ) < 0.001 && mc2.getCargo() != null : "MailCoach second constructor not working";
        Shipment s1 = new Shipment( 12, "Stolat", 106.7, 45 );
        Shipment s2 = new Shipment( 44, "Stolat", 10.5, 13 );
        mc2.addShipment( s1 );
        mc2.addShipment( s2 );
        assert mc2.getVolume() == 58 : "MailCoach addShipment not working";
        assert Math.abs( mc2.getWeight() - 117.2 ) < 0.001 : "MailCoach addShipment not working";
        assert mc2.getCargo().get( 0 ) == s1 : "MailCoach addShipment not working";
        assert mc2.getCargo().get( 1 ) == s2 : "MailCoach addShipment not working";
        System.out.println( "MailCoach all tests passed" );
    }//DO NOT ALTER THIS METHOD
    
    public static ArrayList< Shipment > readData( String fileName ) {
        //IMPLEMENT THIS METHOD
        
        Scanner in = null;
        String inFile = fileName;
        
        try {
            File f = new File(inFile);
            in = new Scanner(f);
        }
        catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
        
                
        ArrayList<Shipment> shipList = new ArrayList<Shipment>();

            
        while(in.hasNext()) {
           String tempLine = in.nextLine();
           String[] tempArray = tempLine.split(" ");
           
        
           int tempId = Integer.parseInt(tempArray[7].replace("#", ""));;
           String tempDestination = tempArray[4];
           double tempWeight = Double.parseDouble(tempArray[0]); 
           tempArray[2] = tempArray[2].replace("(","");
           tempArray[2] = tempArray[2].replace(")","");
           int tempVolume = Integer.parseInt(tempArray[2]);
           
           Shipment tempShip = new Shipment(tempId, tempDestination, tempWeight, tempVolume);
           shipList.add(tempShip);
           
        }
            
        return shipList;

    }
    
    
    /** 
     * volume limit: 100 units
     * weight limit: 500 lbs
     * 
     * if cargo has 50+ units volume and/or 250+ lbs are dispatched
    */
   
    public static ArrayList< MailCoach > sortData( String destination, ArrayList< Shipment > allMail ) {
        ArrayList<MailCoach> mailList = new ArrayList<MailCoach>();
        MailCoach tempCoach = new MailCoach(destination);
        mailList.add(tempCoach);
        
        for(int i = 0; i < allMail.size(); i++) {
            
            // iterate through each shipment to check if the destination fits
            if ((allMail.get(i).getDestination()).equals(destination)){    
                
                for(int j = 0;j < mailList.size(); j++) {
                    if(((500 - mailList.get(j).getWeight()) >= allMail.get(i).getWeight()) || ((100 - mailList.get(j).getVolume()) >= allMail.get(i).getVolume())){
                        mailList.get(j).addShipment(allMail.get(i));
                        break;
                    }
                    
                    // else {
                        // MailCoach tempCoach2 = new MailCoach(destination);
                        // mailList.add(tempCoach2);
                        // mailList.get(j).addShipment(allMail.get(i));
                    // }
                }
                
                if (!mailList.contains(allMail.get(i))) {
                    MailCoach tempCoach2 = new MailCoach(destination);
                    mailList.add(tempCoach2);
                    mailList.get(mailList.size() - 1).addShipment(allMail.get(i));
                }
            }
        }
        
        return mailList;
    }
    

    public static void printReport( ArrayList< MailCoach > mc ) {
        System.out.printf("Next week's mail coaches to %s:%n", mc.get(0).getDestination());
        for(int i = 0; i < mc.size(); i++) {
            if(mc.get(i).getWeight() == 500 || mc.get(i).getVolume() == 100) {
                System.out.printf("    DISPATCH: coach %d (shipments", i + 1);
                for(int j = 0; j < mc.get(i).getCargo().size(); j++) {
                    System.out.printf(" #%d", mc.get(i).getCargo().get(j).getId());
                }
                System.out.printf(")%n");
            }
            else if(mc.get(i).getWeight() > 0 || mc.get(i).getVolume() > 0){
                System.out.printf("    HOLD:    coach %d (shipments", i + 1);
                for(int j = 0; j < mc.get(i).getCargo().size(); j++) {
                    System.out.printf(" #%d", mc.get(i).getCargo().get(j).getId());
                }
                System.out.printf(")%n");  
            }
            else {
                System.out.println("    NO SHIPMENTS");
            }
        }
    }
}
